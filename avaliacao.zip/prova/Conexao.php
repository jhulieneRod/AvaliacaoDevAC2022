<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Conexao
 *
 * @author Area central
 */
class Conexao {

  private $nome;
  private $host;
  private $usuario;
  private $senha;

  private $timeZone;
  public $conexao;
  private $query;

  function __construct($sNome = 'avaliacao', $sHost = 'localhost', $sUsuario = 'root', $sSenha = '') {
    $this->nome    = $sNome;
    $this->host    = $sHost;
    $this->usuario = $sUsuario;
    $this->senha   = $sSenha;
    $this->setConexao();
  }

  public function setConexao() {
    if(!empty($this->host) && !empty($this->usuario)) {
      if (@$this->conexao = mysqli_connect($this->host, $this->usuario, $this->senha)) {
        mysqli_select_db($this->conexao, $this->nome);

        mysqli_query($this->conexao, 'SET character_set_connection=utf8');
        mysqli_query($this->conexao, 'SET character_set_client=utf8');
        mysqli_query($this->conexao, 'SET character_set_results=utf8');

        $nOffset = -10800;
        $this->timeZone = sprintf('Etc/GMT+%s', ($nOffset / 3600 * -1));

        date_default_timezone_set($this->timeZone);

        $this->query(sprintf("SET time_zone = '%s'", date('P')));
        date_default_timezone_set($this->timeZone);
      } else {
        echo 'Nosso banco de dados não está respondendo à solicitação de acesso, já estamos verificando. Por favor aguarde!';
      }
    } else {
      echo 'not working';
    }
  }

  public function query($sSql, $bReturn = false) {
    if($rQry = mysqli_query($this->conexao, $sSql)) {
      if($bReturn) {
        return $rQry;
      } else {
        $this->query = $rQry;
      }
    }
  }

  public function getQuery() {
    return $this->query;
  }

  public function closeConexao() {
    mysqli_close($this->conexao);
  }

  public function getArrayResults() {
    $aReturn = [];
    while ($aDados = mysqli_fetch_array($this->query, MYSQLI_ASSOC)) {
      $aReturn[] = $aDados;
    }
    return $aReturn;
  }

  public function getObjectResults() {
    $oRetorno = false;
    while ($oResult = mysqli_fetch_object($this->query)) {
      $oRetorno = $oResult;
    }
    return $oRetorno;
  }

  public function getAllObjectResults($sTabela, $sCondicao = false) {
    $sSql = 'SELECT * FROM '.$sTabela;
    if($sCondicao){
      $sSql .= ' WHERE '.$sCondicao;
    }
    $this->query = mysqli_query($this->conexao, $sSql);
    $aRetorno = [];
    while($oResult = mysqli_fetch_object($this->query)) {
      $aRetorno[] = $oResult;
    }
    return $aRetorno;
  }

  public function getTotalVendasPorProduto($iProduto) {
    $this->query = mysqli_query($this->conexao, 'SELECT SUM(valor_total) AS valor FROM tbvenda WHERE codigo_produto = '.$iProduto);
    if($oResult = mysqli_fetch_object($this->query)) {
      return $oResult->valor;
    }
    return 0;
  }

  public function getAllVendas() {
    $sSql = 'SELECT tbproduto.codigo, 
                    tbproduto.descricao, 
                    tbvenda.quantidade, 
                    tbvenda.valor_unitario, 
                    tbvenda.valor_total 
              FROM tbvenda 
              JOIN tbproduto 
                ON tbproduto.codigo = tbvenda.codigo_produto';
    $this->query = mysqli_query($this->conexao, $sSql);
    $aRetorno = [];
    while($oResult = mysqli_fetch_object($this->query)) {
      $aRetorno[] = $oResult;
    }
    return $aRetorno;
  }

}

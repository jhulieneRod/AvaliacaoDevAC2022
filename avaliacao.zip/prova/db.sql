/** Criação do banco avaliacao */
CREATE SCHEMA IF NOT EXISTS avaliacao;

USE avaliacao;

/** Criação da tabela de Produto*/
CREATE TABLE tbproduto(
    codigo INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    descricao varchar(100) NOT NULL,
    valor_unitario DECIMAL(7,2) NOT NULL,
    codigo_barras VARCHAR(100) NOT NULL,
    estoque INT NOT NULL,
    ultima_venda DATE,
    excluido SMALLINT
);

/** Criação da tabela de Venda*/
CREATE TABLE tbvenda(
    codigo INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    quantidade INT NOT NULL,
    valor_total DECIMAL(7,2) NOT NULL,
    valor_unitario DECIMAL(7,2) NOT NULL,
    codigo_produto INT NOT NULL,
    FOREIGN KEY (codigo_produto) REFERENCES tbproduto (codigo)
);
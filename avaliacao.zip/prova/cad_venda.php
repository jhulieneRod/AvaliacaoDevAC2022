<?php
    require_once 'model_venda.php';
    if(isset($_POST['botao'])){
        if($_POST['botao'] == 'Inserir'){
            $oVenda = new Venda;
            $oVenda->setValores();
            $oVenda->insereVenda();
        }
    }
?>
<?php 
require_once 'conexao.php';
class Produto {
    private $codigo;
    private $descricao;
    private $estoque;
    private $codigoBarras;
    private $valorUnitario;
    private $excluido;

    function setValores() {
        if(isset($_POST['codigo'])){
            $this->codigo = $_POST['codigo'];
        }
        if(isset($_POST['descricao'])){
            $this->descricao = $_POST['descricao'];
        }
        if(isset($_POST['estoque'])){
            $this->estoque = $_POST['estoque'];
        }
        if(isset($_POST['codigo_barras'])){
            $this->codigoBarras = $_POST['codigo_barras'];
        }
        if(isset($_POST['valor_unitario'])){
            $this->valorUnitario = $_POST['valor_unitario'];
        }
    }

    public function getCodigo(){
        return $this->codigo;
    }

    public function getDescricao(){
        return $this->descricao;
    }

    public function getEstoque(){
        return $this->estoque;
    }

    public function getCodigoBarras(){
        return $this->codigoBarras;
    }

    public function getValorUnitario(){
        return $this->valorUnitario;
    }

    public function setProduto($iCodigo){
        $sCondicao = 'codigo = '.$iCodigo;
        $oConexao = new Conexao;
        $aProdutos = $oConexao->getAllObjectResults('tbproduto', $sCondicao);
        foreach($aProdutos as $oProduto){
            $this->codigoBarras  = $oProduto->codigo_barras;
            $this->valorUnitario = $oProduto->valor_unitario;
            $this->excluido      = $oProduto->excluido;
            $this->descricao     = $oProduto->descricao;
            $this->estoque       = $oProduto->estoque;
        }
    }

    public function insereProduto(){
        $sql = 'INSERT INTO tbproduto (descricao, estoque, codigo_barras, valor_unitario, excluido) 
                VALUES ("'.$this->getDescricao().'",'.$this->getEstoque().',"'.$this->getCodigoBarras().'",'.$this->getValorUnitario().', 0)';
        $con = new Conexao;
        $result = $con->query($sql);
        header('Location: form-produto-edit.php?codigo='.mysqli_insert_id($con->conexao));
    }

    public function alteraProduto(){
        $sql = 'UPDATE tbproduto SET 
                descricao = "'.$this->getDescricao().'",
                estoque = '.$this->getEstoque().',
                codigo_barras ="'.$this->getCodigoBarras().'",
                valor_unitario ='.$this->getValorUnitario().'
                WHERE codigo = '.$this->getCodigo();
        $con = new Conexao;
        $result = $con->query($sql);
        header('Location: produtos.php');
    }

    public function deletaProduto($iCodigo){
        $sql = 'UPDATE tbproduto SET 
                excluido = 1
                WHERE codigo = '.$iCodigo;
        $con = new Conexao;
        $result = $con->query($sql);
        header('Location: produtos.php');
    }

    public function restaurarProduto($iCodigo){
        $sql = 'UPDATE tbproduto SET 
                excluido = 0
                WHERE codigo = '.$iCodigo;
        $con = new Conexao;
        $result = $con->query($sql);
        header('Location: produtos.php');
    }

    public function buscaDados($iCodigo){
        $sCondicao = 'codigo = '.$iCodigo;
        $oConexao = new Conexao;
        $aProdutos = $oConexao->getAllObjectResults('tbproduto', $sCondicao);
        foreach($aProdutos as $oProduto){
            $this->codigo_barras  = $oProduto->codigo_barras;
            $this->valor_unitario = $oProduto->valor_unitario;
            $this->bExcluido      = $oProduto->excluido;
            $this->sDescricao     = $oProduto->descricao;
            $this->iEstoque       = $oProduto->estoque;
        }
    }
}
?>
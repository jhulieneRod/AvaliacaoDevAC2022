<?php
require_once 'conexao.php';
    class Venda {
        private $produto;
        private $quantidade;
        private $valorUnitario;
        private $valorTotal;
        private $alteraValorProduto;

        function setValores() {
            $this->produto            = $_POST['produto'];
            $this->quantidade         = $_POST['quantidade'];
            $this->valorUnitario      = $_POST['valor_unitario'];
            $this->valorTotal         = $_POST['valor_total'];
            $this->alteraValorProduto = $_POST['atualiza_valor_unitario'];
        }

        public function getProduto(){
            return $this->produto;
        }

        public function getQuantidade(){
            return $this->quantidade;
        }

        public function getValorTotal(){
            return $this->valorTotal;
        }

        public function getValorUnitario(){
            return $this->valorUnitario;
        }

        public function getAlteraValorProduto(){
            return $this->alteraValorProduto;
        }

        public function insereVenda(){
            $sSqlVenda = 'INSERT INTO tbvenda(codigo_produto, quantidade, valor_unitario, valor_total) 
                    VALUES ('.$this->getProduto().','.$this->getQuantidade().','.$this->getValorUnitario().','.$this->getValorTotal().')';
            $con = new Conexao;
            $result = $con->query($sSqlVenda);
            $sSql = 'UPDATE tbproduto SET ultima_venda = current_date';
            if($this->getAlteraValorProduto()){
                $sSql .= ', valor_unitario = '.$this->getValorUnitario();
            }
            $sSql .= ' WHERE codigo = '.$this->getProduto();
            $result = $con->query($sSql);
            header('Location: form-venda.php');
        }
    }
?>
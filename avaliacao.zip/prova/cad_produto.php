<?php
    require_once ('model_produto.php');
    if(isset($_POST['botao'])){
        $oBotao = $_POST['botao'];
    }else if(isset($_GET['botao'])){
        $oBotao = $_GET['botao'];
    }else{
       $oBotao = '';
    }

    $oProduto = new Produto;
    if($oBotao == 'Inserir'){
        $oProduto->setValores();
        $oProduto->insereProduto();
    }else if ($oBotao == 'alterar'){
        $oProduto->setValores();
        $oProduto->alteraProduto();
    }else if($oBotao == 'Deletar'){
        $iCodigo = $_GET['codigo'];
        $oProduto->deletaProduto($iCodigo);
    }else if($oBotao == 'Restaurar'){
        $oProduto->restaurarProduto($_GET['codigo']);
    }else if($oBotao == 'getDados'){
        if(isset($_POST['codigo'])){
            $oProduto->buscaDados($_POST['codigo']);
            echo json_encode($oProduto);
        }
    }
?>